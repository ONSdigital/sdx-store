Changelog
=============

Unreleased
----------
- Add function to set pika logging level
- Add codacy badge
