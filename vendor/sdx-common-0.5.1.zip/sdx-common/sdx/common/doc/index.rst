..  Titling
    ##++::==~~--''``

SDX package guide
:::::::::::::::::

.. include:: ../../../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   changelog
   log_levels
   survey
   processor
   transformers
   formats
   cli

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
